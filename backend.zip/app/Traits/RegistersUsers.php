<?php

/*
 * This file is part of AWS Cognito Auth solution.
 *
 * (c) EllaiSys <support@ellaisys.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace App\Traits;

use App\Cognito\AwsCognitoClient;
use Aws\CognitoIdentity\Exception\CognitoIdentityException;
use Aws\CognitoIdentityProvider\Exception\CognitoIdentityProviderException;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

//use Ellaisys\Cognito\AwsCognitoClient;

use Exception;
use Ellaisys\Cognito\Exceptions\InvalidUserFieldException;
use Ellaisys\Cognito\Exceptions\AwsCognitoException;

trait RegistersUsers
{

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
     */
    public function register(Request $request)
    {
        $cognitoRegistered=false;

        //Validate request
        $this->validator($request->all())->validate();

        //Create credentials object
        $collection = collect($request->all());

        //Register User in Cognito
        $cognitoRegistered=$this->createCognitoUser($collection);
        if ($cognitoRegistered==true) {
            //Create data to save
            $data = $request->all();
            unset($data['password']);

            //Create user in local store
            $user = $this->create($data);
        } //End if

        return $request->wantsJson()
            ? new JsonResponse([], 201)
            : redirect($this->redirectPath());
    } //Function ends


    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Support\Collection  $request
     * @return \Illuminate\Http\Response
     * @throws InvalidUserFieldException
     */
    public function createCognitoUser(Collection $request, array $clientMetadata=null)
    {
        try{
            
        //Initialize Cognito Attribute array
        $attributes = [];

        //Get the configuration for new user invitation message action. 
        $messageAction = config('cognito.new_user_message_action', null);

        //Get the configuration for the forced verification of new user
        $isUserEmailForcedVerified = config('cognito.force_new_user_email_verified', false);

        //Get the registeration fields
        $userFields = config('cognito.cognito_user_fields');

        //Iterate the fields
        foreach ($userFields as $key => $userField) {
            if ($request->has($userField)) {
               // var_dump($key);
                $attributes[$key] = $request->get($userField);
            } else {
                Log::error('RegistersUsers:createCognitoUser:InvalidUserFieldException');
                Log::error("The configured user field {$userField} is not provided in the request.");
                throw new InvalidUserFieldException("The configured user field {$userField} is not provided in the request.");
            } //End if
        } //Loop ends

        //Register the user in Cognito
        $userKey = $request->has('username')?'username':'email';

        //Temporary Password paramter
        $password = $request->has('password')?$request['password']:null;
       // var_dump($attributes);
       

       $register = app()->make(AwsCognitoClient::class)->register(
            $request[$userKey], $password, $attributes);
           // var_dump($register);
            return  (bool)$register;
    } //Function ends
    catch(AwsCognitoException $e){
        throw $e->getMessage();

    }
    catch(CognitoIdentityProviderException $e){
        throw $e;

    }
    catch(CognitoIdentityException $e){
        throw $e->getMessage();

    }
}

} //Trait ends